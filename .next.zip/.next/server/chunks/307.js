"use strict";
exports.id = 307;
exports.ids = [307];
exports.modules = {

/***/ 350:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "TD": () => (/* binding */ getCms),
/* harmony export */   "Gw": () => (/* binding */ getWPPost),
/* harmony export */   "ZP": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(184);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(167);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_1__);


const getCms = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAsyncThunk)("getCms", async () => {
  const res = await axios__WEBPACK_IMPORTED_MODULE_1___default().get(`https://cms.heroarena.app/api/hero-arena?populate=popups,popups.image,popup,popup.image,seo,seo.thumbnail,partners,partners.logo,investors,investors.logo,mediaPress,mediaPress.logo,exchangeInformation,exchangeInformation.logo,frame,frame.image`);
  console.log(res.data);
  return res.data;
});
const getWPPost = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAsyncThunk)("getWPPost", async () => {
  const res = await axios__WEBPACK_IMPORTED_MODULE_1___default().get(`https://blog.heroarena.app/wp-json/wp/v2/posts?page=1`);
  console.log(res.data);
  return res.data;
});
const initialState = {
  cmsLoading: true,
  cmsData: null,
  wpLoading: true,
  wpData: null
};
const cmsSlice = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createSlice)({
  name: "cmsSlice",
  initialState,
  reducers: {},
  extraReducers: builder => {
    builder.addCase(getCms.pending, state => {
      state.cmsLoading = true;
    });
    builder.addCase(getCms.fulfilled, (state, {
      payload
    }) => {
      state.cmsLoading = false;
      state.cmsData = payload;
    });
    builder.addCase(getCms.rejected, state => {
      state.cmsLoading = false;
    });
    builder.addCase(getWPPost.pending, state => {
      state.wpLoading = true;
    });
    builder.addCase(getWPPost.fulfilled, (state, {
      payload
    }) => {
      state.wpLoading = false;
      state.wpData = payload;
    });
    builder.addCase(getWPPost.rejected, state => {
      state.wpLoading = false;
    });
  }
});
const {} = cmsSlice.actions;
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (cmsSlice.reducer);

/***/ }),

/***/ 490:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ZA": () => (/* binding */ setPopup),
/* harmony export */   "ZP": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* unused harmony exports increase, decrease */
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(184);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__);

const initialState = {
  count: 20,
  popupOpen: false
};
const counterSlice = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createSlice)({
  name: "counter",
  initialState,
  reducers: {
    increase: state => {
      state.count++;
    },
    decrease: state => {
      state.count--;
    },
    setPopup: (state, action) => {
      state.popupOpen = action.payload;
      sessionStorage["popup-flag"] = true;
    }
  }
});
const {
  increase,
  decrease,
  setPopup
} = counterSlice.actions;
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (counterSlice.reducer);

/***/ })

};
;